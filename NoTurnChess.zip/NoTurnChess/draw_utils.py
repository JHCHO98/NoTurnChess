import chess
import pygame

WIDTH, HEIGHT = 1200,800
BACKGROUND_COLOR = (200, 200, 200)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY  = (150, 150, 150)
DARK_GRAY = (100, 100, 100)

pygame.init()

piece_to_image_path = {
    'P': 'assets/wpawn.png',
    'N': 'assets/wknight.png',
    'B': 'assets/wbishop.png',
    'R': 'assets/wrook.png',
    'Q': 'assets/wqueen.png',
    'K': 'assets/wking.png',
    'p': 'assets/bpawn.png',
    'n': 'assets/bknight.png',
    'b': 'assets/bbishop.png',
    'r': 'assets/brook.png',
    'q': 'assets/bqueen.png',
    'k': 'assets/bking.png',
}



def draw_pieces(screen: pygame.Surface, board_fen, SQUARE_SIZE, left_margin, top_margin, color, cool_time, now):
    board=chess.Board()
    board.set_board_fen(board_fen)
    for file in range(8):
        for rank in range(8):
            square=0
            if color == chess.WHITE:
                square = chess.square(file,7-rank)
                name=str(board.piece_at(square))
            else:
                square = chess.square(7-file, rank)
                name=str(board.piece_at(chess.square(7-file,rank)))
            if name =='None':continue
            image_path = piece_to_image_path[name]
            
            Image=pygame.image.load(image_path).convert_alpha()
            Image = pygame.transform.scale(Image, (22,62))

            screen.blit(Image, (left_margin+SQUARE_SIZE*file+(SQUARE_SIZE-Image.get_width())//2, top_margin+SQUARE_SIZE*rank+(65-Image.get_height())))

            if square in cool_time:
                time_left = 400-(now-cool_time[square])
                time_left /= 400

                height=SQUARE_SIZE*time_left
                surface = pygame.Surface((SQUARE_SIZE,SQUARE_SIZE), pygame.SRCALPHA)
                pygame.draw.rect(surface, (255,255,255), (0, 0, SQUARE_SIZE, height))

                surface.set_alpha(128)

                screen.blit(surface, (left_margin+SQUARE_SIZE*file,top_margin+SQUARE_SIZE*rank+SQUARE_SIZE-height))


FONT_PATH="assets/font.ttf"  # 예시 폰트 파일 경로
font       = pygame.font.Font(FONT_PATH, 40)
label_font = pygame.font.Font(FONT_PATH, 28)
btn_font   = pygame.font.Font(FONT_PATH, 32)


def draw_button(screen: pygame.Surface, rect:pygame.Rect, text:str, hover=False):
    pygame.draw.rect(screen, BLACK if not hover else DARK_GRAY, rect, border_radius=6)
    txt = btn_font.render(text, True, WHITE)
    screen.blit(txt, (rect.centerx - txt.get_width()//2,
                       rect.centery - txt.get_height()//2))
    
def draw_information(screen:pygame.Surface, turn:bool):
    
    T='w' if turn else 'b'
    name=['pawn', 'knight', 'bishop', 'rook', 'queen', 'king']
    cost=[2,3,4,5,7,3]

    for i in range(6):
        piece_name = name[i]
        piece_cost = cost[i]
        surface = pygame.Surface((110, 80), pygame.SRCALPHA, 32)
        surface = surface.convert_alpha()

        img = pygame.transform.scale(pygame.image.load(f'assets/{T}{piece_name}.png'),(22,62))
        text = label_font.render(f' : {piece_cost}', True, BLACK)

        surface.blit(img, (0,9))
        surface.blit(text, (65,40-text.get_height()//2))

        screen.blit(surface, (415+(i%3)*170, 640+80*(i//3)))