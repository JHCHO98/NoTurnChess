from objects import Gauge_bar, Board, BoardEventListener
import chess
import pygame
from client import GameNetworkClient
from draw_utils import draw_pieces, draw_information

pygame.init()

# Colors
WIDTH, HEIGHT = 1200,800
LIGHT = (255, 255, 255)
DARK = (0, 0, 0)
GAUGE_COLOR = (0, 0, 0)
BACKGROUND_COLOR = (200, 200, 200)



# Board settings
BOARD_WIDTH = 560
BOARD_HEIGHT = 560
SQUARE_SIZE = BOARD_WIDTH // 8

board_left_margin = (WIDTH - BOARD_WIDTH) // 2
board_top_margin = 30


BOARD= Board(BOARD_WIDTH, BOARD_HEIGHT, left_margin=board_left_margin, top_margin=board_top_margin)



# 게이지 설정
total_slots = 10
slot_width = 70
slot_height = 40
slot_margin = 3
gauge_x = board_left_margin + (BOARD_WIDTH - (total_slots * slot_width + (total_slots - 1) * slot_margin)) // 2
gauge_y = board_top_margin + BOARD_HEIGHT + 20

gauge = Gauge_bar(total_slots, slot_width, slot_height, slot_margin, gauge_x, gauge_y,currnet_fill=5, rate=1)



# 시간 관련 설정
fill_interval = 800  # 1초 간격
dt = 0  # 시간 차이 초기화
last_fill_time = pygame.time.get_ticks()

clock = pygame.time.Clock()


chessboard = chess.Board()

TURN=True
boardeventlistener=None
running=True
started=False
won=None
end_time=-1
cool_time={} #chess.square, last_move


def game_loop(screen: pygame.Surface, client: GameNetworkClient, room_id: str = '', turn=chess.WHITE):
    global started, running, boardeventlistener, TURN, chessboard, last_fill_time, dt, total_slots, fill_interval, gauge, cool_time, won, end_time

    TURN=turn
    
    boardeventlistener = BoardEventListener(SQUARE_SIZE, board_left_margin, board_top_margin, TURN)

    # ─── 1) 네트워크 콜백 정의 ──────────────────────────────────────────────
    def on_game_state_update(game_data):
        """
        서버로부터 받은 게임 상태를 로컬 체스판과 엘릭서 게이지에 반영합니다.
        game_data keys:
          - 'board' (FEN piece‐placement)
          - 'elixir_rate' (float)
          - 'game_time' (float)
        """
        # 1. 체스판 동기화
        if chessboard.board_fen() != game_data['board']:
            move_sound = pygame.mixer.Sound('assets/move.ogg')
            move_sound.play()
            chessboard.set_board_fen(game_data['board'])

        # 2. 엘릭서 배율 동기화
        gauge.change_rate(game_data['elixir_rate'])

        # BOARD 혹은 별도 렌더러에 전달해 추가 유닛을 그릴 수 있습니다.

    def on_error(msg: str):
        print(f"[Network error] {msg}")

    def on_game_start(colors):
        global TURN, boardeventlistener, started
        started = True
        TURN = colors[client.player_id]
        start_sound=pygame.mixer.Sound('assets/start.ogg')
        start_sound.play()
        boardeventlistener = BoardEventListener(SQUARE_SIZE, board_left_margin, board_top_margin, TURN)
    
    def on_game_end(winner, board):
        global chessboard, end_time
        chessboard.set_board_fen(board)
        end_time = pygame.time.get_ticks()
        end_sound=pygame.mixer.Sound('assets/end.ogg')
        end_sound.play()
        global won, TURN, started
        if winner == TURN or winner is None:
            won=True
            print('won!')
        else:
            won=False
            print('lost!')
        started=False

    # ─── 2) 콜백 등록 & 방 연결 ──────────────────────────────────────────
    client.set_callbacks(
        on_game_state_update=on_game_state_update,
        on_error=on_error,
        on_game_start=on_game_start,
        on_game_end=on_game_end
    )
    client.connect_to_room(room_id)


    clock = pygame.time.Clock()
    FPS = 45
    background_image = pygame.image.load('assets/background.png')
    while running:
        
        

        now = pygame.time.get_ticks()
        selected=False
        cost=0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running=False
            else:
                if started:
                    # 로컬 클릭 → 이동 시도
                    moved = boardeventlistener.update(event, chessboard, gauge, now, cool_time)
                    if moved:
                        move_sound = pygame.mixer.Sound('assets/move.ogg')
                        move_sound.play()
                        # 서버에 내 이동 알림 (FEN 전송)
                        if moved == 2:
                            client.move_piece(chessboard, end=True)
                            started=False
                            won=True
                            end_time = now
                        client.move_piece(chessboard)

        if not started:
            last_fill_time == now

        
        else:    
            chessboard.turn = TURN

            for square, time in cool_time.copy().items():
                if now-time>400:
                    del cool_time[square]
            dt = now - last_fill_time
            if started and gauge.current_fill < total_slots and dt >= fill_interval:
                gauge.fill()
                last_fill_time = now
                dt = 0
            if gauge.current_fill == total_slots:
                last_fill_time = now

            cost = boardeventlistener.get_selected_cost(chessboard=chessboard)
            selected=False
            if cost is not None:
                selected=True




        # ─── 4) 렌더링 ───────────────────────────────────────────────────────

        
        background_image = pygame.transform.scale(background_image, (1200,800))
        screen.blit(background_image, (0,0))
        BOARD.draw(screen)                    # 체스판 + 기본 피스
        draw_pieces(screen, chessboard.board_fen(), SQUARE_SIZE, board_left_margin, board_top_margin, TURN, cool_time, now)
        boardeventlistener.draw(screen)           # 선택 강조
        if started:
            gauge.draw(screen, dt, fill_interval, selected, cost) # 엘릭서 게이지
        else:
            gauge.draw(screen, dt, fill_interval, False, 0)
        draw_information(screen, TURN)
        if won is not None:
            if won:
                Image = pygame.image.load('assets/victory.jpg')
            else:
                Image = pygame.image.load('assets/defeat.png')
            
            Image=pygame.transform.scale(Image, (360, 240))
            time_passed = min((now-end_time),1000)

            if now-end_time<=3000:

                time_passed /= 1000
                surface = pygame.Surface((360,240), pygame.SRCALPHA)
                surface.blit(Image, (0,0))

                surface.set_alpha(time_passed*255)

                screen.blit(surface, (420,280))
            else:
                break
        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    exit()