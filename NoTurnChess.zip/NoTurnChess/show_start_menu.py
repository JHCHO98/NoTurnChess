import pygame,sys
from draw_utils import draw_button

pygame.init()

WIDTH, HEIGHT = 1200,800
pygame.display.set_caption("Clash & Check - Start Menu")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY  = (150, 150, 150)
DARK_GRAY = (100, 100, 100)
BACKGROUND_COLOR = (200, 200, 200)

FONT_PATH  = "assets/font.ttf"  # 예시 폰트 파일 경로
font       = pygame.font.Font(FONT_PATH, 60)
label_font = pygame.font.Font(FONT_PATH, 28)
btn_font   = pygame.font.Font(FONT_PATH, 32)

background_image = pygame.image.load('assets/background.png')


def show_start_menu(screen: pygame.Surface):
    clock = pygame.time.Clock()


    # 버튼
    btn_rect = pygame.Rect(WIDTH//2 - 120, 430, 240, 62)

    running = True
    while running:
        hover = btn_rect.collidepoint(pygame.mouse.get_pos())

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and hover:
                return 'start'  # 게임 시작 버튼 클릭 시

        # ── 그리기 ───────────────────────────
        screen.blit(background_image, (0,0))

        # 타이틀
        title = font.render("Clash & Check 시작하기", True, BLACK)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 200))
        draw_button(screen, btn_rect, "게임 시작", hover)

        pygame.display.flip()
        clock.tick(60)


if __name__ == "__main__":
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    show_start_menu(screen)  # 시작 메뉴 화면 보여주기
    pygame.quit()  # 게임 종료
    sys.exit()  # 프로그램 종료