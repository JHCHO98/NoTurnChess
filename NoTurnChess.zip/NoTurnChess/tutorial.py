import pygame
import math

def tutorial(screen: pygame.surface):
    # 화면 설정
    WIDTH, HEIGHT = 1200, 800

    # 폰트 설정 (시스템 폰트로 대체)

    font = pygame.font.Font("assets/font.ttf", 24)
    font_title = pygame.font.Font("assets/font.ttf", 36)
    font_subtitle = pygame.font.Font("assets/font.ttf", 20)
    # 색상 팔레트
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    DARK_BLUE = (25, 42, 86)
    LIGHT_BLUE = (58, 123, 213)
    GOLD = (255, 215, 0)
    SILVER = (192, 192, 192)
    PURPLE = (138, 43, 226)
    SOFT_WHITE = (248, 248, 255)
    SHADOW_COLOR = (0, 0, 0, 80)
    ACCENT_COLOR = (255, 99, 71)


    # 그라데이션 배경 생성
    def create_gradient_surface(width, height, start_color, end_color):
        surface = pygame.Surface((width, height))
        for y in range(height):
            ratio = y / height
            r = int(start_color[0] * (1 - ratio) + end_color[0] * ratio)
            g = int(start_color[1] * (1 - ratio) + end_color[1] * ratio)
            b = int(start_color[2] * (1 - ratio) + end_color[2] * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (width, y))
        return surface

    # 텍스트에 그림자 효과 추가
    def draw_text_with_shadow(surface, text, font, color, shadow_color, x, y, shadow_offset=3):
        # 그림자 먼저 그리기
        shadow_surface = font.render(text, True, shadow_color)
        surface.blit(shadow_surface, (x + shadow_offset, y + shadow_offset))
        
        # 원본 텍스트 그리기
        text_surface = font.render(text, True, color)
        surface.blit(text_surface, (x, y))
        return text_surface.get_rect(x=x, y=y)

    # 카드 스타일 박스 그리기
    def draw_card_box(surface, x, y, width, height, color, border_color, border_width=3):
        # 그림자 효과
        shadow_rect = pygame.Rect(x + 5, y + 5, width, height)
        pygame.draw.rect(surface, (0, 0, 0, 100), shadow_rect, border_radius=15)
        
        # 메인 박스
        main_rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(surface, color, main_rect, border_radius=15)
        pygame.draw.rect(surface, border_color, main_rect, border_width, border_radius=15)
        
        return main_rect

    def draw_start_button(surface, rect: pygame.Rect, color, border_color, border_width=3):
        # 그림자 효과
        x, y=rect.x, rect.y
        width, height = rect.width, rect.height

        shadow_rect = pygame.Rect(x + 5, y + 5, width, height)
        pygame.draw.rect(surface, (0, 0, 0, 100), shadow_rect, border_radius=15)
        
        # 메인 박스
        main_rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(surface, color, main_rect, border_radius=15)
        pygame.draw.rect(surface, border_color, main_rect, border_width, border_radius=15)

        draw_text_with_shadow(surface, 'Start!', font, (255,255,255), (150,150,150), x+215, y+20)




    # 게임 데이터
    title = 'CLASH & CHECK 시작하기!!!'
    rules = [
        "클래시 & 체크는 체스에 엘릭서 자원 시스템을 도입한 실시간 전략 게임입니다.",
        "",
        "플레이어는 시작 시 5 엘릭서를 가지며, 매턴 1씩 회복되고 최대 10까지 저장됩니다.",
        "",
        "기물을 움직일 때 엘릭서를 소모하며, 부족할 경우 이동 불가입니다.",
        "",
        "",
        "기물별 소모량은 다음과 같습니다:",
        "",
        "",
        "폰 2, 나이트 3, 비숍 4, 룩 5, 퀸 7, 킹 3",
        "",
        "캐슬링 3, 프로모션 2"
    ]

    # 체스 말별 정보
    pieces_info = [
        ("폰", 2, "♟"),
        ("나이트", 3, "♞"),
        ("비숍", 4, "♝"),
        ("룩", 5, "♜"),
        ("퀸", 7, "♛"),
        ("킹", 3, "♚")
    ]

    # 초기화
    scroll_y = 100
    scroll_speed = 5
    clock = pygame.time.Clock()
    running = True
    time = 0
    particles = []
    background = create_gradient_surface(WIDTH, HEIGHT, DARK_BLUE, LIGHT_BLUE)

    # 메인 루프
    while running:
        dt = clock.tick(60) / 1000.0
        time += dt
        
        scroll_y = min(scroll_y,0)
        scroll_y = max(scroll_y, -200)

        
        # 배경 그리기
        screen.blit(background, (0, 0))
        
        # 타이틀 박스
        title_box = draw_card_box(screen, 50, 30 + scroll_y, WIDTH - 100, 80, SOFT_WHITE, GOLD, 4)
        
        # 애니메이션 효과가 있는 타이틀
        title_y_offset = int(5 * math.sin(time * 2))
        draw_text_with_shadow(screen, title, font_title, PURPLE, BLACK, 80, 50 + scroll_y + title_y_offset, 4)
        
        # 메인 콘텐츠 박스
        content_box = draw_card_box(screen, 50, 130 + scroll_y, WIDTH - 100, 180, SOFT_WHITE, LIGHT_BLUE, 3)
        
        # 규칙 텍스트
        y = 150 + scroll_y
        for i, line in enumerate(rules):
            if line.strip():
                # 중요한 줄은 하이라이트
                if "엘릭서" in line or "소모량" in line:
                    text_color = ACCENT_COLOR
                else:
                    text_color = DARK_BLUE
                
                draw_text_with_shadow(screen, line, font, text_color, (200, 200, 200), 80, y, 2)
            y += 30
        
        # 체스 말 정보 카드들
        card_start_y = y + 30
        for i, (piece, cost, symbol) in enumerate(pieces_info):
            card_x = 80 + (i % 3) * 350
            card_y = card_start_y + (i // 3) * 100
            
            # 말별 카드 배경
            piece_card = draw_card_box(screen, card_x, card_y, 300, 70, WHITE, SILVER, 2)
            
            # 체스 말 기호
            symbol_surface = font_title.render(symbol, True, DARK_BLUE)
            screen.blit(symbol_surface, (card_x + 20, card_y + 15))
            
            # 말 이름
            name_surface = font.render(piece, True, DARK_BLUE)
            screen.blit(name_surface, (card_x + 70, card_y + 15))
            
            # 엘릭서 코스트
            cost_text = f"엘릭서 {cost}"
            cost_surface = font_subtitle.render(cost_text, True, ACCENT_COLOR)
            screen.blit(cost_surface, (card_x + 70, card_y + 40))
            
            # 코스트 시각화 (작은 원들)
            for j in range(cost):
                circle_x = card_x + 180 + j * 15
                circle_y = card_y + 35
                pygame.draw.circle(screen, GOLD, (circle_x, circle_y), 6)
                pygame.draw.circle(screen, DARK_BLUE, (circle_x, circle_y), 6, 2)
        
        # 특수 동작 정보
        special_y = card_start_y + 200
        special_actions = [("캐슬링", 3), ("프로모션", 2)]
        
        draw_text_with_shadow(screen, "특수 동작:", font, PURPLE, BLACK, 80, special_y, 2)
        
        for i, (action, cost) in enumerate(special_actions):
            action_x = 80 + i * 350
            action_y = special_y + 40
            
            # 특수 동작 카드
            action_card = draw_card_box(screen, action_x, action_y, 320, 50, WHITE, PURPLE, 2)
            
            # 동작 이름
            action_surface = font.render(action, True, DARK_BLUE)
            screen.blit(action_surface, (action_x + 20, action_y + 15))
            
            # 코스트
            cost_text = f"엘릭서 {cost}"
            cost_surface = font_subtitle.render(cost_text, True, ACCENT_COLOR)
            screen.blit(cost_surface, (action_x + 150, action_y + 17))
        
        start_y = special_y + 100

        draw_start_button(screen, pygame.Rect(350, start_y+30, 500, 70), (0,255,0), (30,225,10))
        

        # 이벤트 처리
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_UP:
                    scroll_y += scroll_speed * 3
                elif event.key == pygame.K_DOWN:
                    scroll_y -= scroll_speed * 3
            elif event.type == pygame.MOUSEWHEEL:
                scroll_y += event.y * 30
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos=event.pos

                if pygame.Rect(350, start_y+30, 500, 70).collidepoint(pos):
                    running=False

        # 프레임 업데이트
        pygame.display.flip()


if __name__ == '__main__':
    pygame.init()
    screen = pygame.display.set_mode((1200, 800))
    pygame.display.set_caption("Clash & Check - Start Menu")
    tutorial(screen)