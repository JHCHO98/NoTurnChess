import asyncio
import websockets
import json
import threading
import requests
from typing import Callable, Optional, Dict, Any
import uuid

import chess

class GameNetworkClient:
    def __init__(self, server_url: str = "ws://localhost:8080"):
        self.server_url = server_url
        self.http_url = server_url.replace("ws://", "http://").replace("wss://", "https://")
        self.websocket = None
        self.room_id = None
        self.player_id = str(uuid.uuid4())
        self.connected = False
        self.running = False
        
        # 콜백 함수들
        self.on_game_state_update: Optional[Callable] = None
        self.on_connection_status: Optional[Callable] = None
        self.on_error: Optional[Callable] = None
        
        # 비동기 이벤트 루프를 위한 스레드
        self.loop = None
        self.thread = None
    
    def set_callbacks(self, 
                     on_game_state_update: Callable = None,
                     on_connection_status: Callable = None,
                     on_game_start:Callable = None,
                     on_error: Callable = None,
                     on_game_end: Callable = None):
        """콜백 함수 설정"""
        self.on_game_state_update = on_game_state_update
        self.on_connection_status = on_connection_status
        self.on_game_start = on_game_start
        self.on_error = on_error
        self.on_game_end = on_game_end
    
    def create_room(self) -> Optional[str]:
        """새 방 생성"""
        try:
            response = requests.post(f"{self.http_url}/create_room")
            if response.status_code == 200:
                data = response.json()
                return data.get('room_id')
        except Exception as e:
            if self.on_error:
                self.on_error(f"방 생성 실패: {e}")
        return None
    
    def get_rooms(self) -> list:
        """활성 방 목록 조회"""
        try:
            response = requests.get(f"{self.http_url}/rooms")
            if response.status_code == 200:
                data = response.json()
                return data
        except Exception as e:
            if self.on_error:
                self.on_error(f"방 목록 조회 실패: {e}")
        return []
    
    def connect_to_room(self, room_id: str):
        """방에 연결"""
        self.room_id = room_id
        self.running = True
        
        # 새 스레드에서 비동기 연결 시작
        self.thread = threading.Thread(target=self._start_async_connection)
        self.thread.daemon = True
        self.thread.start()
    
    def _start_async_connection(self):
        """비동기 연결을 새 이벤트 루프에서 시작"""
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        
        try:
            self.loop.run_until_complete(self._connect_websocket())
        except Exception as e:
            if self.on_error:
                self.on_error(f"연결 실패: {e}")
        finally:
            self.loop.close()
    
    async def _connect_websocket(self):
        """WebSocket 연결"""
        ws_url = f"{self.server_url}/ws/{self.room_id}/{self.player_id}"
        
        try:
            async with websockets.connect(ws_url) as websocket:
                self.websocket = websocket
                self.connected = True
                
                if self.on_connection_status:
                    self.on_connection_status(True)
                
                # 메시지 수신 루프
                async for message in websocket:
                    if not self.running:
                        break
                    
                    try:
                        data = json.loads(message)
                        await self._handle_message(data)
                    except json.JSONDecodeError as e:
                        if self.on_error:
                            self.on_error(f"메시지 파싱 실패: {e}")
                        
        except websockets.exceptions.ConnectionClosed as e:
            if self.on_connection_status:
                self.on_connection_status(False)
        except Exception as e:
            if self.on_error:
                self.on_error(f"WebSocket 연결 실패: {e}")
        finally:
            self.connected = False
            if self.on_connection_status:
                self.on_connection_status(False)
    
    async def _handle_message(self, data: Dict[str, Any]):
        """서버로부터 받은 메시지 처리"""
        message_type = data.get('type')
        
        if message_type == 'game_state':
            # 게임 상태 업데이트
            game_data = data.get('data', {})
            if self.on_game_state_update:
                self.on_game_state_update(game_data)
                
        elif message_type == 'game_start':
            player_colors=data.get('color',{})
            self.on_game_start(player_colors)
        elif message_type == 'game_ended':
            self.on_game_end(data.get('winner'), data.get('board'))
        
        elif message_type == 'error':
            # 에러 메시지
            error_msg = data.get('message', 'Unknown error')
            if self.on_error:
                self.on_error(f"서버 에러: {error_msg}")
    
    def send_message(self, message: Dict[str, Any]):
        """서버로 메시지 전송 (메인 스레드에서 호출)"""
        if not self.connected or not self.loop:
            return
        
        # 비동기 함수를 다른 스레드의 이벤트 루프에서 실행
        asyncio.run_coroutine_threadsafe(
            self._send_message_async(message), 
            self.loop
        )
    
    async def _send_message_async(self, message: Dict[str, Any]):
        """비동기 메시지 전송"""
        if self.websocket and self.connected:
            try:
                await self.websocket.send(json.dumps(message))
            except Exception as e:
                if self.on_error:
                    self.on_error(f"메시지 전송 실패: {e}")
    
    def move_piece(self, board: chess.Board, end:bool = False):
        """피스 이동"""
        message = {
            "type": "move", 
            "data": board.board_fen(),  # FEN 문자열로 보드 상태 전송
        }

        self.send_message(message)
        if end:
            message= {
                'type':'ended'
            }
            self.send_message(message)
    
    def disconnect(self):
        """연결 종료"""
        self.running = False
        self.connected = False
        
        if self.websocket:
            # WebSocket 연결 종료를 비동기적으로 처리
            if self.loop and self.loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    self.websocket.close(), 
                    self.loop
                )
        
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1)

# 사용 예시
if __name__ == "__main__":
    def on_game_state_update(game_data):
        print(f"게임 상태 업데이트: {game_data}")
        print(f"게임 시간: {game_data.get('game_time', 0):.1f}초")

    def on_connection_status(connected):
        print(f"연결 상태: {'연결됨' if connected else '연결 끊김'}")

    def on_error(error_msg):
        print(f"에러: {error_msg}")

    # 클라이언트 생성
    client = GameNetworkClient()
    client.set_callbacks(
        on_game_state_update=on_game_state_update,
        on_connection_status=on_connection_status,
        on_error=on_error
    )
    
    # 방 생성 또는 기존 방 조회
    room_id = client.create_room()
    print(f"생성된 방 ID: {room_id}")
    
    # 방에 연결
    if room_id:
        client.connect_to_room(room_id)
        
        # 연결 대기
        import time
        time.sleep(2)
        
        # 테스트 피스 배치
        board = chess.Board()
        
        # 프로그램 종료 대기
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("프로그램 종료")
            client.disconnect()