from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import asyncio
import json
import uuid
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import time
import chess

app = FastAPI(title="Clash & Check Server")

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PieceType(Enum):
    PAWN = "pawn"
    ROOK = "rook"
    KNIGHT = "knight"
    BISHOP = "bishop"
    QUEEN = "queen"
    KING = "king"

class Player(Enum):
    WHITE = "white"
    BLACK = "black"

@dataclass
class GamePiece:
    type: PieceType
    player: Player
    cost: int
    health: int
    max_health: int
    x: int
    y: int
    id: str

@dataclass
class GameState:
    board: str  # FEN 문자열로 보드 상태 저장
    max_elixir: float
    elixir_rate: float
    game_time: float
    
    def to_dict(self):
        return {
            'board': self.board,
            'elixir_rate': self.elixir_rate,
            'game_time': self.game_time
        }

class GameRoom:
    def __init__(self, room_id: str):
        self.room_id = room_id
        self.players: Dict[str, WebSocket] = {}
        self.player_colors: Dict[str, Player] = {}
        self.game_state = GameState(
            board=chess.Board().board_fen(),
            max_elixir=10.0,
            elixir_rate=1.0,
            game_time=0.0
        )
        self.last_update = time.time()
        self.game_running = False
        self.winner = None
        
    async def add_player(self, player_id: str, websocket: WebSocket):
        self.players[player_id] = websocket
        
        # 플레이어 색상 할당
        if len(self.players) == 1:
            self.player_colors[player_id] =chess.WHITE
        elif len(self.players) == 2:
            self.player_colors[player_id] = chess.BLACK
            self.game_running = True
            await self.start_game()
        
        await self.broadcast_game_state()
    
    async def remove_player(self, player_id: str):
        if player_id in self.players:
            del self.players[player_id]
        if player_id in self.player_colors:
            del self.player_colors[player_id]
        self.game_running = False
        del game_rooms[self.room_id]
    
    async def start_game(self):   
        await self.broadcast_game_start()
        # 게임 루프 시작
        asyncio.create_task(self.game_loop())

    
    async def game_loop(self):
        """메인 게임 루프"""
        self.game_state.game_time=0
        while self.game_running and len(self.players) == 2:
            current_time = time.time()
            dt = current_time - self.last_update
            self.last_update = current_time
            # 게임 시간 업데이트
            self.game_state.game_time += dt
            
            # 게임 상태 브로드캐스트
            await self.broadcast_game_state()
            
            await asyncio.sleep(0.1)  # 100ms마다 업데이트
        
        await self.broadcast_game_end()
    
    async def handle_move(self, player_id: str, board: str):
        """플레이어 이동 처리"""
        if not self.game_running:
            print('not running')
            return
        self.game_state.board = board
    
    async def terminate_game(self, player_id: str):
        if self.game_running:
            self.game_running = False
            self.winner = self.player_colors[player_id]
    
    async def broadcast_game_start(self):
        if not self.players:
            return
        
        message={
            'type':'game_start',
            'color':self.player_colors
        }

        disconnected_players = []
        for player_id, websocket in self.players.items():
            try:
                await websocket.send_text(json.dumps(message))
            except Exception as e:
                print(e)
                disconnected_players.append(player_id)
        
        # 연결 끊긴 플레이어 제거
        for player_id in disconnected_players:
            await self.remove_player(player_id)

    async def broadcast_game_state(self):
        """모든 플레이어에게 게임 상태 전송"""
        if not self.players:
            return
        
        message = {
            'type': 'game_state',
            'data': self.game_state.to_dict(),
            'running':False
        }
        
        disconnected_players = []
        for player_id, websocket in self.players.items():
            try:
                await websocket.send_text(json.dumps(message))
            except Exception as e:
                print(e)
                disconnected_players.append(player_id)
        
        # 연결 끊긴 플레이어 제거
        for player_id in disconnected_players:
            await self.remove_player(player_id)
        

        #플레이어가 모두 나가면 방 제거
        if not self.players:
            del game_rooms[self.room_id]

    async def broadcast_game_end(self):
        message={
            'type': 'game_ended',
            'board': self.game_state.board,
            'winner': self.winner
        }
        for player_id, websocket in self.players.items():
            try:
                await websocket.send_text(json.dumps(message))
            except Exception as e:
                pass

# 전역 게임 룸 관리
game_rooms: Dict[str, GameRoom] = {}

@app.get("/")
async def root():
    return {"message": "Clash & Check Server"}

@app.get("/rooms")
async def get_rooms():
    R={
        room_id: {
            "players": list(room.players.keys()),
            "player_colors": {k: v for k, v in room.player_colors.items()},
            "game_running": room.game_running,
        }
        for room_id, room in game_rooms.items()
    }
    return R

@app.post("/create_room")
async def create_room():
    room_id = len(game_rooms)
    game_rooms[room_id] = GameRoom(room_id)
    return {"room_id": room_id}

@app.websocket("/ws/{room_id}/{player_id}")
async def websocket_endpoint(websocket: WebSocket, room_id: str, player_id: str):
    await websocket.accept()
    # 방이 없으면 생성
    if room_id not in game_rooms:
        game_rooms[room_id] = GameRoom(room_id)
    
    room = game_rooms[room_id]
    
    try:
        await room.add_player(player_id, websocket)
        
        while True:
            try:
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30)
                message = json.loads(data)

                if message['type'] == 'move':
                    board=message['data']
                    await room.handle_move(player_id, board)
                if message['type'] == 'ended':
                    await room.terminate_game(player_id)
                    break
            except asyncio.TimeoutError:
                continue
            
    except WebSocketDisconnect as e:
        print(e)
        await room.remove_player(player_id)
    
        # 방이 비어있으면 삭제
        if not room.players:
            del game_rooms[room_id]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)