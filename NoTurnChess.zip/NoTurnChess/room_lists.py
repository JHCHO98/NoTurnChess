import pygame
import sys
from client import GameNetworkClient
from draw_utils import draw_button

WIDTH, HEIGHT = 1000,800
BACKGROUND_COLOR = (200, 200, 200)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY  = (150, 150, 150)

pygame.init()


FONT_PATH="malgungothic"  # 예시 폰트 파일 경로
font       = pygame.font.SysFont(FONT_PATH, 40)
label_font = pygame.font.SysFont(FONT_PATH, 28)
btn_font   = pygame.font.SysFont(FONT_PATH, 32)


def show_room_list(screen, client):
    clock = pygame.time.Clock()
    
    # 버튼
    btn_rect = pygame.Rect(WIDTH//2 - 120, 430, 240, 62)

    running = True
    while running:
        hover = btn_rect.collidepoint(pygame.mouse.get_pos())

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and hover:
                return 'start'  # 게임 시작 버튼 클릭 시

        # ── 그리기 ───────────────────────────
        screen.fill(BACKGROUND_COLOR)

        # 타이틀
        title = font.render("방 목록", True, BLACK)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 200))
        
        # 방 목록 표시
        rooms = client.get_rooms()
        y_offset = 250
        for room_id, room in rooms.items():
            room_text = f"방 ID: {room_id}, 플레이어 수: {len(room['players'])}"
            room_label = label_font.render(room_text, True, BLACK)
            screen.blit(room_label, (WIDTH//2 - room_label.get_width()//2, y_offset))
            y_offset += 30

        draw_button(screen, btn_rect, "게임 시작", hover)

        pygame.display.flip()
        clock.tick(60)


if __name__ == "__main__":
    # 클라이언트 생성
    client = GameNetworkClient()
    
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Clash & Check - 방 목록")

    # 방 목록 표시
    show_room_list(screen, client)