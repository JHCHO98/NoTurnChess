# start_menu.py
import pygame, sys, os
import chess
pygame.init()

from show_start_menu import show_start_menu
from game_loop import game_loop
from tutorial import tutorial


WIDTH, HEIGHT = 1200,800

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY  = (150, 150, 150)
DARK_GRAY = (100, 100, 100)
BACKGROUND_COLOR = (200, 200, 200)

from client import GameNetworkClient

def on_game_state_update(game_data,chessboard: chess.Board):
    if 'fen' in game_data:
        chessboard.set_fen(game_data['fen'])

def on_connection_status(connected):
    print(f"연결 상태: {'연결됨' if connected else '연결 끊김'}")

def on_error(error_msg):
    print(f"에러: {error_msg}")

# 클라이언트 생성
client = GameNetworkClient()
client.set_callbacks(
    on_game_state_update=on_game_state_update,
    on_connection_status=on_connection_status,
    on_error=on_error
)



screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Clash & Check - Start Menu")

# 초기 상태 설정
state='start_menu'  # 초기 상태 설정

def main(client: GameNetworkClient):
    global state
    tutorial(screen=screen)
    while True:
        if state == 'start_menu':
            result = show_start_menu(screen)
            if result == 'start':
                state = 'game'
        elif state == 'game':
            rooms=client.get_rooms()

            room_id = None

            for id in rooms:
                room=rooms[id]
                if len(room['players'])<2:
                    room_id=id

            if room_id is None:
                room_id = client.create_room()
            game_loop(screen,client, room_id=room_id, turn=True)
            break

# 프로그램 종료 대기
main(client=client)

pygame.quit()
