import pygame
import chess
from pygame.locals import MOUSEBUTTONDOWN


class Gauge_bar:
    def __init__(self, total_slots, slot_width, slot_height, slot_margin, gauge_x, gauge_y,currnet_fill=5, rate=1.0):
        self.total_slots = total_slots
        self.slot_width = slot_width
        self.slot_height = slot_height
        self.slot_margin = slot_margin
        self.gauge_x = gauge_x
        self.gauge_y = gauge_y
        self.current_fill = currnet_fill
        self.BACKGROUND_COLOR = (150, 150, 150)
        self.GAUGE_COLOR = (0, 0, 0)
        self.rate=rate

    def draw(self, screen, dt, fill_interval=1000, selected=False, cost=None):
        fill_interval /= self.rate
        # 게이지 바 배경 그리기
        pygame.draw.rect(screen, self.BACKGROUND_COLOR, (self.gauge_x, self.gauge_y, self.total_slots * (self.slot_width + self.slot_margin) - self.slot_margin, self.slot_height))
        
        if selected:
            pygame.draw.rect(screen, (255,255,255), (self.gauge_x-self.slot_margin, self.gauge_y-self.slot_margin, self.slot_margin+(self.slot_width+self.slot_margin)*cost, 2*self.slot_margin + self.slot_height))

        for i in range(self.total_slots-1, -1, -1):
            x = self.gauge_x + i * (self.slot_width + self.slot_margin)
            color = self.GAUGE_COLOR if i < self.current_fill else self.BACKGROUND_COLOR

            if i == self.current_fill:
                width = ((dt / fill_interval) ** 5) * self.slot_width * 1.2
                pygame.draw.rect(screen, self.BACKGROUND_COLOR, (x, self.gauge_y, self.slot_width, self.slot_height))
                pygame.draw.rect(screen, self.GAUGE_COLOR, (x, self.gauge_y, width, self.slot_height))
            else:
                pygame.draw.rect(screen, color, (x, self.gauge_y, self.slot_width, self.slot_height))
        


    
    def fill(self):
        self.current_fill += 1

    def change_rate(self,rate):
        self.rate = rate


class Board:
    def __init__(self, width, height, left_margin=0, top_margin=0):
        self.width = width
        self.height = height
        self.squares = [[None for _ in range(8)] for _ in range(8)]
        self.colors = [(200, 200, 200), (50, 50, 50)]
        self.left_margin = left_margin
        self.top_margin = top_margin
    
    def draw(self, screen):
        square_size = self.width // 8
        for row in range(8):
            for col in range(8):
                color = self.colors[(row + col) % 2]
                pygame.draw.rect(screen, color, (col * square_size+self.left_margin, row * square_size + self.top_margin, square_size, square_size))


piece_to_cost = {
    'P': 2,
    'N': 3,
    'B': 4,
    'R': 5,
    'Q': 7,
    'K': 3
}


class BoardEventListener:
    def __init__(self, square_size, left_margin, top_margin, color):
        self.square_size = square_size
        self.left_margin = left_margin
        self.top_margin = top_margin
        self.selected_square = None
        self.color=color

    def get_square_under_mouse(self, pos):
        x, y = pos
        col = (x - self.left_margin) // self.square_size
        row = (y - self.top_margin) // self.square_size
        if 0 <= col < 8 and 0 <= row < 8:
            # chess.square(file, rank) with rank 0=1st rank, so invert row
            if self.color == chess.WHITE:
                return chess.square(col, 7 - row)
            else:
                return chess.square(7-col, row)
        return None

    def update(self, event: pygame.event, chessboard:chess.Board, gauge: Gauge_bar, now, cool_time: dict):
        """
        Handle mouse click events.
        Returns True if an attempted move was made (valid or not), False otherwise.
        """
        if event.type == MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            square = self.get_square_under_mouse(pos)
            if square is None:
                return False

            if self.selected_square is None and ((square not in cool_time) or (square in cool_time and now-cool_time[square] > 400)):
                piece = chessboard.piece_at(square)
                if piece and piece.color == chessboard.turn:
                    self.selected_square = square
            elif self.selected_square is not None:
                # 두 번째 클릭: 이동 시도
                piece = chessboard.piece_at(self.selected_square)
                if piece and piece.color == chessboard.turn:

                    move = chess.Move(self.selected_square, square)
                    try:
                        move=chessboard.find_move(self.selected_square, square, chess.QUEEN)
                    except chess.IllegalMoveError as e:
                        pass
                    if move in chessboard.pseudo_legal_moves:
                        
                        cost = self.get_selected_cost(chessboard=chessboard)
                        
                        if cost<= gauge.current_fill:
                            ret=1
                            if str(chessboard.piece_at(square=square)).upper() == 'K':
                                print('end')
                                ret=2
                            chessboard.push(move)    
                            gauge.current_fill -= cost
                                            # 선택 초기화
                            self.selected_square = None
                            cool_time[square]=now

                            return ret
                    else:
                        # 첫 클릭: 내 말 선택
                        piece = chessboard.piece_at(square)
                        if piece and piece.color == chessboard.turn:
                            self.selected_square = square
                else:
                    self.selected_square = None

                
        return False

    def draw(self, screen):
        """
        Highlight the selected square on the board.
        """
        if self.selected_square is not None:
            col = chess.square_file(self.selected_square)
            row = 7 - chess.square_rank(self.selected_square)
            if self.color == chess.BLACK:
                col=7-col
                row=7-row
            rect = pygame.Rect(
                self.left_margin + col * self.square_size,
                self.top_margin + row * self.square_size,
                self.square_size,
                self.square_size
            )
            pygame.draw.rect(screen, (239, 228, 176), rect, 3)

    def get_selected_cost(self, chessboard: chess.Board):
        if self.selected_square is not None:
            piece = chessboard.piece_at(self.selected_square)
            cost=piece_to_cost[str(piece).upper()]
        
            return cost
        return None